<?php
/**
 * Plugin Name: Archangel Reaction 
 * Plugin URI:  https://aerty.my.id/app/plugin/arch-reaction
 * Description: Menambahkan Reaction Button Custom Ke Wordpress, dalam Bentuk Iframe.
 * Version:     1.5.0 Eternal
 * Author:      Aerty Gouchin
 * Author URI:  https://aerty.my.id
 * Text Domain: arch-reaction
 */
 if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ARCH_REACTION_VERSION', '1.5.0' );
define( 'ARCH_REACTION_PATH_DIR' , __DIR__ );
define( 'ARCH_REACTION_PATH_URL' , plugin_dir_url(__FILE__) );

add_action('init', function() {
    require_once plugin_dir_path(__FILE__).'class.core.php';
    $GLOBALS['ARCH_REACTION'] = new ArchCore(ARCH_REACTION_VERSION);
    // DISABLE SITE MAP
    //add_filter( 'wp_sitemaps_enabled', '__return_false' );
    function generate_reaction_iframe(){
      global $ARCH_REACTION;
      echo $ARCH_REACTION->render_handle_reaction_iframe();
    }
});