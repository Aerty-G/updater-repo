<?php 

class ArchReact {
    public $option;
    public $base_url = '';
    const REACT_OPTION_NAME = 'se_reaction_list';
    const REACT_COUNT_META = 'se_reaction_count';
    const IS_DEBUG = false;
    
    public function __construct()
    {
      // index
      $this->option = new stdClass();
    }
    
    public function init() {
      add_action('wp_ajax_se_handle_reaction', [$this, 'ajax_handler']);
      add_action('wp_ajax_nopriv_se_handle_reaction', [$this, 'ajax_handler']);
      add_shortcode( 'sextras_reaction', [$this, 'handle_shortcode'] );
      $this->get_config();
    }
    
    private function get_config() {
      $config_file = __DIR__ . '/reaction-config.php';
      $example_file = __DIR__ . '/reaction-config.php.example';
      if ( ! file_exists($config_file) ) {
          if ( file_exists($example_file) ) {
              if ( copy($example_file, $config_file) ) {
                  error_log('File config.php berhasil dibuat dari config.php.example');
              } else {
                  error_log('Gagal membuat file config.php dari config.php.example');
              }
          } else {
              error_log('File config.php.example tidak ditemukan!');
          }
      }
      $this->option->config = include($config_file);
    }
    
    public function getReaction() {
      return get_option( self::REACT_OPTION_NAME, array( array( 'name' => '', 'icon' => '' ) ) );
    }
    
    public function getRactionCount( $id = '' ) {
      $id = empty($id) ? get_the_ID() : $id;
      $count = get_post_meta( $id, self::REACT_COUNT_META, true );
      return empty($count) ? array() : $count;
    }
    
    private function construct_reaction( $id = '' ) {
      $id = empty($id) ? get_the_ID() : $id;
      $array_reaction = get_post_meta( $id, self::REACT_COUNT_META, true );
      if (empty($array_reaction)) {
        $meta = [
          'reaction' => array(0,0,0,0,0,0),
          'all_count' => 0,
          'user' => array(
                'id' => array(),
                'ip' => array()
              )
        ];
        update_post_meta($id, self::REACT_COUNT_META, $meta);
        $array_reaction = $meta;
      }
      $this->option->react = new stdClass();
      $this->option->react->raw = $array_reaction;
      $this->option->react->all_reaction_has_accour = isset($array_reaction['reaction']) ?$array_reaction['reaction'] : array(0,0,0,0,0);
      $this->option->react->all_reaction_count = isset($array_reaction['all_count']) ?$array_reaction['all_count'] : '0';
      $this->option->react->all_user_has_react = isset($array_reaction['user']) ? $array_reaction['user'] : array();
      $this->option->react->user_react = false;
    }
    
    private function base_array_react_list() {
      $array = $this->option->config['react'];
      if (!is_array($array)) return array();
      $array_reaction = [];
      foreach ($array as $value) {
        $array_reaction[] = [
          'image_url' => $this->base_url.$value['image_url'],
          'image_alt' => $value['image_alt'],
          'text' => $value['text']
          ];
      }
      return $array_reaction;
    }

    
    public function handle_shortcode() {
      if (!isset($_GET['id'])) return 'unknown';
      if ( !isset($_GET['id']) || !is_numeric($_GET['id'])) {
        return 'unknown';
        
      } else {
        $post = get_post($_GET['id']);
        if (!$post) return 'invalid';
        return $this->render_ReactionBlock($_GET['id']);
      }
    }
     
    private function has_reacted($key, $user_id = '', $ip = '') {
      if ( $user_id === 0 ) $user_id = '';
      $has_id = isset($this->option->react->all_user_has_react['id'][$user_id]) ? true : false;
      if (!$has_id) { $id_status = false; } else {
      $id_status = ((int)$this->option->react->all_user_has_react['id'][$user_id] === (int)$key) ? true : false; }
      $has_ip = isset($this->option->react->all_user_has_react['ip'][$ip]) ? true : false;
      if (!$has_ip) { $ip_status = false; } else {
      $ip_status = ((int)$this->option->react->all_user_has_react['ip'][$ip] === (int)$key) ? true : false; }
      
      if ($id_status) $this->option->react->user_react = true;
      if ($id_status || $ip_status) return true;
      return false;
      if (!$has_id && $has_ip && !empty($user_id)) {
        $this->option->react->raw['user']['id'][$user_id] = $this->option->react->all_user_has_react['ip'][$ip];
      }
      if ($has_id && !$has_ip && !empty($ip)) {
        $this->option->react->raw['user']['ip'][$ip] = $this->option->react->all_user_has_react['id'][$user_id];
      }
      if (!$has_ip && !$has_id) {
        if (empty($user_id)) {
          
        }
      }
    }
    
    public function render_ReactionBlock($post_id) {
        $this->construct_reaction($post_id);
        $total_responses = $this->option->react->all_reaction_count;
        $css_url = $this->base_url . '/css/react.css?ver=' . filemtime(__DIR__ . '/css/react.css');
        $reactions = $this->base_array_react_list();
        $load_gif_url = $this->base_url . $this->option->config['data']['loading_image'];
    
        ob_start();
        ?>
        <div id="reaction-wrapper">
            <div id="reaction-loader">
              <img src="<?php echo esc_url($load_gif_url); ?>" alt="KuruKuru..." />
            </div>
            <div id="reaction-card" class="reaction-container" style="display:none;">
                <div class="prompt">Gimana Reaksi Kalian?</div>
                <div class="total-responses"><?php echo $total_responses; ?> Respon</div>
                <div class="reaction-items__container">
                    <?php foreach ($reactions as $key => $reaction):
                        if (!isset($reaction['image_url']) || empty($reaction['image_url'])) continue;
                        $count = $this->option->react->all_reaction_has_accour[$key] ?? 0;
                        $is_selected = $this->has_reacted($key, get_current_user_id(), $_SERVER['REMOTE_ADDR']);
                        if ($this->option->react->user_react) $is_selected = false;
                        $selected_class = $is_selected ? 'reaction-item__selected' : '';
                    ?>
                    <button class="reaction-button <?php echo $selected_class; ?>"
                            data-reaction="<?php echo esc_attr($key); ?>"
                            data-post-id="<?php echo $post_id; ?>"
                            title="<?php echo esc_attr($reaction['image_alt']); ?>">
                        <img class="reaction-icon"
                             src="<?php echo esc_url($reaction['image_url']); ?>"
                             alt="<?php echo esc_attr($reaction['image_alt']); ?>" />
                        <span class="reaction-label"><?php echo esc_html($reaction['text']); ?></span>
                        <span class="reaction-count"><?php echo $count; ?></span>
                    </button>
                    <?php endforeach; ?>
                </div>
                <div class="show-more-container" style="display: none;">
                    <button id="show-more-btn" class="show-more-btn">
                        <svg class="show-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 15L8 11H16L12 15Z" fill="currentColor"/>
                        </svg>
                        <span class="show-more-text">Tampilkan Lebih Banyak</span>
                    </button>
                </div>
            </div>
        </div>
        <link rel="stylesheet" href="<?php echo esc_url($css_url); ?>">
        <style>
    
            .reaction-button {
              all: unset;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              padding: 8px;
              border-radius: 8px;
              box-sizing: border-box; 
              width: 100%;
              text-align: center;
            }
    
            .reaction-button:hover,
            .reaction-button.reaction-item__selected {
              border: 2px solid #666;
              background-color: #f0f4f700;
            }
    
            .reaction-icon {
                max-width: 50px;
                max-height: 50px;
                margin-bottom: 4px;
            }
    
            .reaction-label {
                font-size: 12px;
                /* color: #333; */
                white-space: normal;
                line-height: 1.2;
                margin: 0;
                padding: 0 2px;
                word-break: break-word;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                max-width: 100%;
            }
    
            .reaction-count {
                font-size: 12px;
                /* color: #888; */
            }
    
            .prompt {
                text-align: center;
                font-weight: 600;
                font-size: 17px;
                margin-bottom: 4px;
            }
    
            .total-responses {
                text-align: center;
                font-size: 15px;
                /* color: #666; */
                margin-bottom: 12px;
            }
            .reaction-row {
              max-width: 648px;
              margin: 0 auto;
              padding: 16px 12px;
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(64px, 1fr));
              gap: 8px;
              box-sizing: border-box;
              justify-content: center;
            }
            .reaction-row.hide {
              display: none;
            }
    
          @media (max-width: 480px) {
            .reaction-row {
              max-width: 401px;
              grid-template-columns: repeat(3, 1fr); 
              place-items: center; 
            }
          
            .reaction-button {
              padding: 6px;
            }
          
            .reaction-label {
              font-size: 14px;
              white-space: normal;
              word-break: break-word;
              text-overflow: initial;
            }
          
            .reaction-icon {
              max-width: 40px;
              max-height: 40px;
            }
          
            .reaction-count {
              font-size: 11px;
            }
          }
          #reaction-loader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 80dvh;
            background-color: rgba(255,255,255,0);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
            opacity: 1;
          }
          
          #reaction-loader.hide {
            opacity: 0;
            pointer-events: none;
          }
          
          #reaction-loader img {
            max-width: 150px;
            max-height: 150px;
            width: auto;
            height: auto;
          }
          .reaction-button,
          .reaction-label,
          .reaction-row, .show-more-container, .show-more-btn, .show-more-icon, .show-more-text {
            user-select: none;
            -webkit-user-select: none;
            -ms-user-select: none;
          }
          
          .show-more-container {
              text-align: center;
              margin-top: 16px;
              padding-bottom: 8px;
          }
          
          .show-more-btn {
              background-color: transparent;
              border: 1px solid #4d90fe;
              color: #4d90fe;
              cursor: pointer;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              font-size: 14px;
              font-weight: 500;
              padding: 8px 16px;
              border-radius: 24px;
              transition: all 0.3s ease;
              outline: none;
              width: 200px;
          }
          
          .show-more-btn:hover {
              background-color: #4d90fe;
              color: white;
          }
          
          .show-more-btn:hover .show-more-icon path {
              fill: white;
          }
          
          .show-more-icon {
              margin-right: 8px;
              transition: transform 0.3s ease;
          }
          
          .show-more-btn.expanded .show-more-icon {
              transform: rotate(180deg);
          }
          
          .show-more-text {
              display: inline-block;
              transition: all 0.3s ease;
          }
          
          .reaction-button.hidden-reaction {
              display: none;
          }
        </style>
        <!--
          Halo Aku Liat Kamu Nyasar KeMari(?),
          lagi ngapain? Kamu Salah Pencet Url?
          Atau Jangan Jangan Kamu Mau Ikut Ikut Bikin Kayak Gini?
          Kamu Bisa Loh Tanya langsung Sama Adminnya.
          Aku Aerty Gouchin Bisa Aja Bantuin Kamu Buat Kayak Begini.
          Yah Itupun Kalo Kamu Mau.
          hubungin aku lewat discord yak!
          Yaudah Sana Lanjutin Yang lagi kamu lakuin!
          Dadah~
        -->
        <script>
          function sendIframeHeight() {
            //const height = document.documentElement.scrollHeight;
            const el = document.getElementById('reaction-wrapper');
            const height = el.offsetHeight;
            parent.postMessage({ type: 'setHeightReaction', height }, '*');
            setTimeout(() => {
                //const newHeight = document.documentElement.scrollHeight;
                const newHeight = document.body.scrollHeight;
                if (newHeight !== height) {
                    parent.postMessage({ type: 'setHeightReaction', height: newHeight }, '*');
                }
            }, 100);
          }
          
          function initReactionRow() {
            const container = document.querySelector('.reaction-items__container');
            const buttons = Array.from(container.querySelectorAll('.reaction-button'));
            const rows = Array.from(container.querySelectorAll('.reaction-row.can-hide'));
            const showMoreContainer = document.querySelector('.show-more-container');
            
            if (buttons.length > 6) {
                buttons.forEach((button, index) => {
                    if (index >= 6) {
                        button.classList.add('hidden-reaction');
                    }
                });
                rows.forEach((row, index) => {
                  row.classList.add('hide');
                });
                showMoreContainer.style.display = 'block';
                
                const showMoreBtn = document.getElementById('show-more-btn');
                const showMoreText = showMoreBtn.querySelector('.show-more-text');
                let expanded = false;
                
                showMoreBtn.addEventListener('click', function() {
                    expanded = !expanded;
                    
                    buttons.forEach((button, index) => {
                        if (index >= 6) {
                            button.classList.toggle('hidden-reaction', !expanded);
                        }
                    });
                    
                    rows.forEach((row, index) => {
                      row.classList.toggle('hide', !expanded);
                    });
                    
                    if (expanded) {
                        showMoreBtn.classList.add('expanded');
                        showMoreText.textContent = 'Sembunyikan';
                    } else {
                        showMoreBtn.classList.remove('expanded');
                        showMoreText.textContent = 'Tampilkan Lebih Banyak';
                    }
                    
                    setTimeout(sendIframeHeight, 50);
                });
            }
        }
          
          window.addEventListener('resize', () => {
            sendIframeHeight();
          });
          
          window.addEventListener("load", function () {
            setTimeout(() => {
              const loader = document.getElementById("reaction-loader");
              const content = document.getElementById("reaction-card");
          
              if (loader) loader.classList.add("hide");
              if (content) content.style.removeProperty("display");
                const container = document.querySelector('.reaction-items__container');
                const buttons = Array.from(container.querySelectorAll('.reaction-button'));
                container.innerHTML = '';

                for (let i = 0; i < buttons.length; i += 6) {
                    const row = document.createElement('div');
                    row.className = 'reaction-row';
                    if ((i+1) >= 7) row.classList.add('can-hide');
                    buttons.slice(i, i + 6).forEach(btn => row.appendChild(btn));
                    container.appendChild(row);
                }
              initReactionRow();
          
              sendIframeHeight();
              SEReact.System();
            }, 4000);
          });
        var SEReact = {
            key_cache: 'se_reaction',
            ajaxurl: <?php echo json_encode(admin_url('admin-ajax.php')); ?>,
            post_id: <?php echo json_encode($post_id); ?>,
            is_logged_in: <?php echo json_encode(is_user_logged_in()); ?>
        };
    
        SEReact.saveReaction = function(postId, reactionType) {
            const cache = JSON.parse(localStorage.getItem(this.key_cache) || '{}');
            cache[postId] = { reaction: reactionType, timestamp: Date.now() };
            localStorage.setItem(this.key_cache, JSON.stringify(cache));
        }
    
        SEReact.getReaction = function(postId) {
            const cache = JSON.parse(localStorage.getItem(this.key_cache) || '{}');
            return cache[postId]?.reaction || null;
        }
    
        SEReact.System = function() {
            const container = document.querySelectorAll('.reaction-row');
            const full_container = document.querySelector('.reaction-items__container');
            const postId = SEReact.post_id;
            let isAjaxProcessing = false;
            let lenght_button = 0;
    
            // Set from cache
            const cachedReaction = SEReact.getReaction(postId);
            container.forEach(contain => {
              if (cachedReaction && !contain.querySelector('.reaction-item__selected')) {
                  const btn = contain.querySelector(`.reaction-button[data-reaction="${cachedReaction}"]`);
                  if (btn) btn.classList.add("reaction-item__selected");
              }
              lenght_button = contain.querySelectorAll('.reaction-button').length;
              contain.style.maxWidth = 108 * lenght_button + 'px';
              let count_witdh = 108 * lenght_button + 'px';
              //contain.style.cssText = ` `;
            });
            
    
            full_container.querySelectorAll('.reaction-button').forEach(button => {
                button.addEventListener('click', async function () {
                    if (isAjaxProcessing) return;
    
                    const newReaction = this.dataset.reaction;
                    const oldEl = full_container.querySelector('.reaction-item__selected');
                    const oldReaction = oldEl ? oldEl.dataset.reaction : null;
    
                    if (newReaction === oldReaction) return;
    
                    isAjaxProcessing = true;
                    full_container.style.opacity = "0.6";
                    full_container.style.pointerEvents = "none";
    
                    if (oldEl) oldEl.classList.remove("reaction-item__selected");
                    this.classList.add("reaction-item__selected");
    
                    SEReact.saveReaction(postId, newReaction);
    
                    try {
                        const response = await fetch(SEReact.ajaxurl, {
                            method: "POST",
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            body: new URLSearchParams({
                                action: "se_handle_reaction",
                                post_id: postId,
                                new_reaction: newReaction,
                                old_reaction: oldReaction,
                                is_logged_in: SEReact.is_logged_in
                            })
                        });
    
                        const data = await response.json();
    
                        if (data.success) {
                            if (oldReaction) {
                                const oldCountEl = full_container.querySelector(`.reaction-button[data-reaction="${oldReaction}"] .reaction-count`);
                                if (oldCountEl) oldCountEl.textContent = data.data.old_count;
                            }
    
                            const newCountEl = full_container.querySelector(`.reaction-button[data-reaction="${newReaction}"] .reaction-count`);
                            if (newCountEl) newCountEl.textContent = data.data.new_count;
    
                            const totalEl = document.querySelector(".total-responses");
                            if (totalEl) totalEl.textContent = data.data.total + " Respon";
    
                            for (let i = 0; i < data.data.other; i++) {
                              const countEl = container.querySelector(`.reaction-button[data-reaction="${i}"] .reaction-count`);
                              if (countEl) countEl.textContent = data.data.other[i];
                            }
                        }
    
                    } catch (error) {
                        console.error("Reaction error:", error);
                        this.classList.remove("reaction-item__selected");
                        if (oldEl) oldEl.classList.add("reaction-item__selected");
                        SEReact.saveReaction(postId, oldReaction);
                    } finally {
                        isAjaxProcessing = false;
                        full_container.style.opacity = "1";
                        full_container.style.pointerEvents = "auto";
                    }
                });
            });
        }
        
        
        </script>
        <?php
        return ob_get_clean();
    }
    
    public function render_html_on_post($with_script = true) {
      global $post;
      ob_start();
      ?>
        <div id="archangel-reaction">
        <br>
        <?php if ($with_script) { ?>
        <script>
          function changeColor(iframe) {
            
            const themeElement = document.querySelector('#comments .releases h2');
            const styles = getComputedStyle(themeElement);
            const bg = styles.backgroundColor;
            const color = styles.color;
          
            const style = document.createElement('style');
            style.textContent = `
              body {
                background-color: ${bg} !important;
                color: ${color} !important;
              }
            `;
          
            try {
              const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
              iframeDoc.head.appendChild(style);
            } catch (e) {
              console.warn("Tidak bisa akses isi iframe (mungkin beda origin):", e);
            }
          }
        </script>
        <?php } ?>
        <iframe id="arch-reaction" name="arch-reaction" onload="changeColor(this)" allowtransparency="true" frameborder="0" scrolling="no" tabindex="0" title="Reaction" style="width: 100%; height: 286px; border: medium;" src="/reaction/?id=<?php echo esc_attr(($post->ID !== '') ? $post->ID : get_the_ID()); ?>">
        </iframe>
        <?php if ($with_script) { ?>
        <script>
          window.addEventListener('message', function (event) {
            //console.log(event);
            if (event.data.type === 'setHeightReaction') {
              const iframe = document.getElementById('arch-reaction');
              if (iframe) {
                iframe.style.height = event.data.height + 'px';
              }
            }
          });
        </script> 
        <?php } ?>
        </div>
      <?php
      return ob_get_clean();
    }
    
    public function ajax_handler() {
        //check_ajax_referer('se_reaction_nonce', 'security');
    
        $post_id = (int) $_POST['post_id'];
        $new_reaction = (int) $_POST['new_reaction'];
        $old_reaction = (isset($_POST['old_reaction']) && $_POST['old_reaction'] !== 'null') ? (int) $_POST['old_reaction'] : false;
        $is_logged_in = $_POST['is_logged_in'] === 'true';
        
        if (self::IS_DEBUG) {
          error_log('Is Login: ' . ($is_logged_in ? 'true' : 'false'));
          error_log('Post Id: ' . $post_id);
          error_log('Old React Id: ' . var_export($old_reaction, true));
          error_log('New React Id: ' . $new_reaction);
        }
        $post = get_post($post_id);
        
    
        $response = [
            'success' => false,
            'data' => [
                'old_count' => 0,
                'new_count' => 0,
                'total' => 0,
                'other' => [],
            ]
        ];
        if (!$post) return wp_send_json($response);
    
        try {
            $this->construct_reaction($post_id);
            $change_count = true;
            if ($is_logged_in) {
              $user_id = get_current_user_id();
              if (isset($this->option->react->raw['user']['id'][$user_id]) && $this->option->react->raw['user']['id'][$user_id] === $new_reaction) {
                  $change_count = false;
              }
              $this->option->react->raw['user']['id'][$user_id] = (int) $new_reaction;
            }
    
            $old_reaction_count = ($old_reaction !== false && isset($this->option->react->all_reaction_has_accour[$old_reaction]))
                ? (int) $this->option->react->all_reaction_has_accour[$old_reaction]
                : 0;
    
            $new_reaction_count = isset($this->option->react->all_reaction_has_accour[$new_reaction])
                ? (int) $this->option->react->all_reaction_has_accour[$new_reaction]
                : 0;
            if ($change_count) {
              $this->option->react->raw['reaction'][$new_reaction] = $new_reaction_count + 1;
              
              if ($old_reaction !== false) {
                  $this->option->react->raw['reaction'][$old_reaction] = max(0, $old_reaction_count - 1);
              }
            }
            $this->gen_total_reaction();
            
            
            update_post_meta($post_id, self::REACT_COUNT_META, $this->option->react->raw);
    
            $response['data']['old_count'] = $this->option->react->raw['reaction'][$old_reaction] ?? 0;
            $response['data']['new_count'] = $this->option->react->raw['reaction'][$new_reaction] ?? 0;
            $response['data']['total'] = $this->option->react->raw['all_count'] ?? 0;
            $response['data']['other'] = $this->option->react->raw['reaction'] ?? [];
            $response['success'] = true;
    
        } catch (Exception $e) {
            error_log("Reaction error: " . $e->getMessage());
        }
    
        wp_send_json($response);
    }
    
    private function gen_total_reaction() {
      $total = 0;
      foreach ($this->option->react->raw['reaction'] as $reaction) {
        $total = $total + (int) $reaction;
      }
      $this->option->react->raw['all_count'] = $total;
    }
    
}