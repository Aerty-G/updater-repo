(function () {
    var hooks = ArchAngelENV.hooks_1 + ((typeof ArchAngelENV.hooks_2 !== 'undefined' && ArchAngelENV.hooks_2 !== '') ? ' ' + ArchAngelENV.hooks_2 : '');
    if (!hooks) {
      console.log('Please Set Again The Hooks');
      return;
    }
    var comment = document.querySelector(hooks.trim());
    //console.log(comment);
    if (!comment) {
      console.log('Please Set Again The Hooks');
      return;
    }
    if (typeof ArchAngelENV !== 'undefined' && ArchAngelENV.html) {
      if ((typeof ArchAngelENV.hooks_2 !== 'undefined' && ArchAngelENV.hooks_2 !== '')) {
        var temp = document.createElement('div');
        temp.innerHTML = ArchAngelENV.html.trim();
        var newElement = temp.firstElementChild;
        if (newElement) {
            comment.insertAdjacentElement('afterend', newElement);
            
        }
      } else {
        const html = ArchAngelENV.html.trim();
        const temp = document.createElement('div');
        temp.innerHTML = html;
        const newEl = temp.firstElementChild;
        if (newEl) {
            comment.insertAdjacentElement('afterbegin', newEl);
        }
      }
    }
}) ();
function changeColor(iframe) {
  var hooks = ArchAngelENV.hooks_1 + ((typeof ArchAngelENV.hooks_2 !== 'undefined' && ArchAngelENV.hooks_2 !== '') ? ' ' + ArchAngelENV.hooks_2 : '');
  var themeElement = document.querySelector(`${hooks} h2`);
  if (!themeElement) themeElement = document.querySelector(`${hooks} h3`);
  if (!themeElement) themeElement = iframe.closest('h2');
  if (!themeElement) themeElement = iframe.closest('h3');
  if (!themeElement) { 
    console.log('h2 or h3 for changeColor is not found'); 
    return; 
  }
  const styles = getComputedStyle(themeElement);
  const bg = styles.backgroundColor;
  const color = styles.color;

  const style = document.createElement('style');
  style.textContent = `
    body {
      background-color: ${bg} !important;
      color: ${color} !important;
    }
  `;

  try {
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    iframeDoc.head.appendChild(style);
  } catch (e) {
    console.warn("Tidak bisa akses isi iframe (mungkin beda origin):", e);
  }
}
window.addEventListener('message', function (event) {
  //console.log(event);
  if (event.data.type === 'setHeightReaction') {
    const iframe = document.getElementById('arch-reaction');
    if (iframe) {
      iframe.style.height = event.data.height + 'px';
    }
  }
});