(function () {
    var comment= document.querySelector('#comments');
    console.log(comment);
    if (!comment) return;
    var release= comment.querySelector('.releases');
    if (!release) return;
    if (typeof ArchAngelENV !== 'undefined' && ArchAngelENV.html) {
        var temp = document.createElement('div');
        temp.innerHTML = ArchAngelENV.html.trim();
        var newElement = temp.firstElementChild;
        if (newElement) {
            release.insertAdjacentElement('afterend', newElement);
            
        }
    }
}) ();
function changeColor(iframe) {
  const themeElement = document.querySelector('#comments .releases h2');
  const styles = getComputedStyle(themeElement);
  const bg = styles.backgroundColor;
  const color = styles.color;

  const style = document.createElement('style');
  style.textContent = `
    body {
      background-color: ${bg} !important;
      color: ${color} !important;
    }
  `;

  try {
    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
    iframeDoc.head.appendChild(style);
  } catch (e) {
    console.warn("Tidak bisa akses isi iframe (mungkin beda origin):", e);
  }
}
window.addEventListener('message', function (event) {
  //console.log(event);
  if (event.data.type === 'setHeightReaction') {
    const iframe = document.getElementById('arch-reaction');
    if (iframe) {
      iframe.style.height = event.data.height + 'px';
    }
  }
});