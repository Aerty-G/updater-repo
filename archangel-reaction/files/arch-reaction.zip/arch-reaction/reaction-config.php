<?php

return [
      'data' => ['loading_image' => '/images/kuru.gif'],
      'react' => [
        array(
          'image_url' => '/images/reaction/upvote.png',
          'image_alt' => 'Lanjut',
          'text' => 'Lanjut Mint!'
          ),
        array(
          'image_url' => '/images/reaction/bruakaka.png',
          'image_alt' => 'Ngakak',
          'text' => 'Ngakak Cik!'
          ),
        array(
          'image_url' => '/images/reaction/kanna-lope.png',
          'image_alt' => 'Kanna',
          'text' => 'Lope!'
          ),
        array(
          'image_url' => '/images/reaction/herta-uwooo.png',
          'image_alt' => 'sedih',
          'text' => 'Huwaa:('
          ),
        array(
          'image_url' => '/images/reaction/fucek.webp',
          'image_alt' => 'Pucek',
          'text' => 'Anj*ng'
          ),
        array(
          'image_url' => '/images/reaction/jahe-woaah.png',
          'image_alt' => 'Jahe',
          'text' => 'Owaahh'
          ) ,
        array(
          'image_url' => '/images/reaction/moona-muehehe.png',
          'image_alt' => 'Ada Moona',
          'text' => 'SangBer'
          ),
        array(
          'image_url' => '/images/reaction/kurukuru.gif',
          'image_alt' => 'Herta Cute',
          'text' => 'KuruKuru'
          ),
        array(
          'image_url' => '/images/reaction/yay.png',
          'image_alt' => 'Hore',
          'text' => 'Hore😃'
          ),
        array(
          'image_url' => '/images/reaction/hamdeh.png',
          'image_alt' => 'Worry',
          'text' => 'Hamdeh'
          ),
        array(
          'image_url' => '/images/reaction/croot.png',
          'image_alt' => 'Keluar Banyak',
          'text' => 'Croot'
          ),
        array(
          'image_url' => '/images/reaction/sus.png',
          'image_alt' => 'Botak',
          'text' => 'SUS🤨'
          ),
        array(
          'image_url' => '/images/reaction/holyshi.png',
          'image_alt' => 'HowlyShiet',
          'text' => 'HowlyShiet'
          ),
        array(
          'image_url' => '/images/reaction/heheh.png',
          'image_alt' => 'Eno',
          'text' => 'Heheh'
          ),
        array(
          'image_url' => '/images/reaction/wkwk.png',
          'image_alt' => 'Wkwk',
          'text' => 'WkWkWk'
          )
        ]];