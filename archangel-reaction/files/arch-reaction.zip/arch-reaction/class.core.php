<?php

require_once(__DIR__.'/class.reaction.php');
require_once(__DIR__.'includes/class.update.php');

class ArchCore {
  public $option;
  
    public function __construct($VERSION = '1.2.0')
    {
      // index
      $this->option = new stdClass();
      $this->option->reaction = new ArchReact();
      $this->option->update = new ArchAngel_Updater($VERSION);
      $this->option->base_url = plugins_url( '', __FILE__ );
      $this->option->reaction->base_url = $this->option->base_url;
      $this->option->reaction->init();
      add_filter( 'theme_page_templates', [$this, 'add_page_template'] );
      add_filter( 'template_include', [$this, 'handle_page_template'] );
    }
    
    public function add_page_template($templates) {
        $templates['templates/reaction-page.php'] = __( 'Reaction Page', 'reaction-page' );
        return $templates;
    }
    
    public function handle_page_template($template) {
        if ( is_page() ) {
            global $post;
            $current_template = get_page_template_slug( $post->ID );
        
            if ( 'templates/reaction-page.php' === $current_template ) {
                $plugin_template = plugin_dir_path( __FILE__ ) . 'templates/reaction-page.php';
                
                    return $plugin_template;
                
            }
        }
        return $template;    
    }
    
    public function render_handle_reaction_iframe() {
      return $this->option->reaction->render_html_on_post();
    }
}

