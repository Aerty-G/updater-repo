<?php

require_once(__DIR__.'/class.reaction.php');
require_once(__DIR__.'/includes/class.update.php');

class ArchCore {
  public $option;
  
    public function __construct($VERSION = '1.2.0')
    {
      // index
      $this->option = new stdClass();
      $this->option->reaction = new ArchReact();
      $this->option->update = new ArchAngel_Updater($VERSION);
      $this->option->base_url = plugins_url( '', __FILE__ );
      $this->option->reaction->base_url = $this->option->base_url;
      $this->option->reaction->init();
      add_filter( 'theme_page_templates', [$this, 'add_page_template'] );
      add_filter( 'template_include', [$this, 'handle_page_template'] );
      add_action('wp_enqueue_scripts', [$this, 'handle_reaction_dynamic_render']);
    }
    
    public function add_page_template($templates) {
        $templates['templates/reaction-page.php'] = __( 'Reaction Page', 'reaction-page' );
        return $templates;
    }
    
    public function handle_page_template($template) {
        if ( is_page() ) {
            global $post;
            $current_template = get_page_template_slug( $post->ID );
        
            if ( 'templates/reaction-page.php' === $current_template ) {
                $plugin_template = plugin_dir_path( __FILE__ ) . 'templates/reaction-page.php';
                
                    return $plugin_template;
                
            }
        }
        return $template;    
    }
    
    

    public function handle_reaction_dynamic_render() {
        if (is_singular(($this->option->reaction->option->config['data']['post_types'] ?? ['post', 'manga']))) {
            wp_enqueue_script(
                'archangel-reaction',
                plugin_dir_url(__FILE__) . 'js/reaction.js',
                ['jquery'],
                filemtime(__DIR__ . '/js/reaction.js'),
                true
            );
    
            $post_data = [
                'html' => $this->render_handle_reaction_iframe(false)
            ];
    
            wp_localize_script('archangel-reaction', 'ArchAngelENV', $post_data);
        }
    }
    
    
    public function render_handle_reaction_iframe($script = true) {
      return $this->option->reaction->render_html_on_post($script);
    }
}

