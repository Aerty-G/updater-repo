<div class="wrap">
    <h1>Pengaturan Reaction</h1>
    
    <div class="reaction-admin-container">
        <h2 class="nav-tab-wrapper">
            <a href="#manage-reactions" class="nav-tab nav-tab-active">Kelola Reaction</a>
            <a href="#manage-images" class="nav-tab">Kelola Gambar</a>
            <a href="#manage-phrase" class="nav-tab">Kelola Phrase</a>
        </h2>
        
        
        <div id="manage-reactions" class="tab-content active">
            <div class="ajax-response"></div>
            
            <form id="save-reactions-form" method="post">
                <div id="reaction-table" class="table-container">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>Gambar</th>
                                <th>Label</th>
                                <th>Aktif</th>
                                <th>Hapus</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reactions as $key => $reaction): ?>
                            <tr class="react-items-<?php echo esc_attr($key); ?>">
                                <td><?php echo esc_html($key); ?></td>
                                <td>
                                    <img src="<?php echo esc_url(plugins_url("../{$reaction['image_url']}", __FILE__)); ?>" 
                                         width="40" height="40" alt="<?php echo esc_attr($reaction['text']); ?>">
                                    <input type="hidden" name="react[<?php echo esc_attr($key); ?>][image_url]" 
                                          value="<?php echo esc_attr($reaction['image_url']); ?>">
                                </td>
                                <td>
                                    <input type="text" name="react[<?php echo esc_attr($key); ?>][text]" 
                                           value="<?php echo esc_attr($reaction['text']); ?>" class="regular-text">
                                </td>
                                <td style="text-align: center;">
                                    <input type="checkbox" name="react[<?php echo esc_attr($key); ?>][active]" 
                                        <?php checked($reaction['active'] ?? true, true); ?> value="1">
                                </td>
                                <td style="text-align: center;">
                                    <a href="#" data-react="<?php echo esc_attr($key); ?>" class="delete-link delete-reaction">Hapus</a>
                                    <!-- <input type="checkbox" name="delete[<?php echo esc_attr($key); ?>]"> -->
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                </br>
                <?php submit_button('Simpan Perubahan', 'primary', 'save_reactions', false, ['id' => 'save-reactions-button']); ?>
                <span class="ajax-loader"></span>
            </form>  
            <div class="ajax-response"></div>
            <form id="add-reactions-form" method="post">
                <h3>Tambah Reaksi Baru atau Memperbaruinya</h3>
                <div class="new-reaction">
                    <div>
                        <label>Key:</label>
                        <input type="text" name="new_reaction[key]" class="regular-text" required>
                        <p class="description">Isi dengan key yang tidak tersedia di list di atas untuk menambahkan Reaction Baru, atau Isi dengan Key Sudah Ada Di list Diatas Untuk Memperbaruinya lebih lanjut.</p>
                    </div> 
                    <div>
                        <label>Label:</label>
                        <input type="text" name="new_reaction[text]" class="regular-text" required>
                        <p class="description">Teks Untuk Di tampilkan dibawah Gambar Reaction.</p>
                    </div>
                    <div>
                        <label>Gambar:</label>
                        <select name="new_reaction[image_url]" class="regular-text" required>
                            <option value="">Pilih Gambar</option>
                            <?php foreach ($images as $image): ?>
                            <option value="<?php echo esc_attr($image); ?>"><?php echo esc_html($image); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">Gambar Yang Akan Ditampilkan sebagai Reaction.</p>
                    </div>
                </div>
                
                <?php submit_button('Add Reaction', 'primary', 'add_reaction', false, ['id' => 'add-reactions-button']); ?>
                <span class="ajax-loader"></span>
            </form>
        </div>
        
        
        <div id="manage-phrase" class="tab-content">
            <div class="ajax-response"></div>
            
            <form id="save-phrase-form" method="post">
                <h3>Pengaturan Kalimat dan Hooks</h3>
                
                <div class="phrase-settings">
                    <div class="phrase-item">
                        <label>Prompt Utama:</label>
                        <input type="text" name="prompt" class="regular-text" 
                               value="<?php echo esc_attr($phrases['prompt']); ?>" 
                               placeholder="Gimana Reaksi Kalian?">
                        <p class="description">Teks yang muncul di atas tombol reaksi</p>
                    </div>
                    
                    <div class="phrase-item">
                        <label>Total Respon:</label>
                        <input type="text" name="total_responses" class="regular-text" 
                               value="<?php echo esc_attr($phrases['total_responses']); ?>" 
                               placeholder="{count} Respon">
                        <p class="description">Gunakan <code>{count}</code> untuk menampilkan jumlah respon</p>
                    </div>
                    
                    <div class="phrase-item">
                        <label>Teks 'Tampilkan Lebih Banyak':</label>
                        <input type="text" name="show_more" class="regular-text" 
                               value="<?php echo esc_attr($phrases['show_more']); ?>" 
                               placeholder="Tampilkan Lebih Banyak">
                    </div>
                    
                    <div class="phrase-item">
                        <label>Teks 'Sembunyikan':</label>
                        <input type="text" name="show_less" class="regular-text" 
                               value="<?php echo esc_attr($phrases['show_less']); ?>" 
                               placeholder="Sembunyikan">
                    </div>
                    
                    <div class="phrase-item">
                        <label>Hook 1:</label>
                        <input type="text" name="hooks_1" class="regular-text" 
                               value="<?php echo esc_attr($phrases['hooks_1'] ??''); ?>" 
                               placeholder="#comments">
                        <p class="description">Untuk Hook Bagian Pertama Yang Akan DiGunakan Pada JS, Lebih Jelasnya Tanyak Dev Atau Liat Documentation Jika Tersedia</p>
                    </div>
                    
                    <div class="phrase-item">
                        <label>Hook 2:</label>
                        <input type="text" name="hooks_2" class="regular-text" 
                               value="<?php echo esc_attr($phrases['hooks_2'] ??''); ?>" 
                               placeholder=".releases">
                        <p class="description">Untuk Hook Bagian Kedua Yang Akan DiGunakan Pada JS, Bisa Dikosongkan apabila hanya ingin memakai satu, Lebih Jelasnya Tanyak Dev Atau Liat Documentation Jika Tersedia</p>
                    </div>
                </div>
                
                <?php submit_button('Simpan Frasa', 'primary', 'save_phrases', false, ['id' => 'save-phrases-button']); ?>
                <span class="ajax-loader"></span>
            </form>
        </div>
        
        
        <div id="manage-images" class="tab-content">
            <div class="ajax-response"></div>
            
            <form id="upload-image-form" method="post" enctype="multipart/form-data">
                <h3>Upload Gambar Baru</h3>
                <div class="upload-section">
                    <input type="file" name="reaction_image" accept=".jpg,.jpeg,.png,.gif,.webp" required>
                    <?php submit_button('Upload Gambar', 'secondary', 'upload_image', false, ['id' => 'upload-image-button']); ?>
                    <span class="ajax-loader"></span>
                </div>
            </form>
            
            <h3>Daftar Gambar Tersedia</h3>
            <div class="image-grid">
                <?php foreach ($images as $image): ?>
                <div class="image-item">
                    <img src="<?php echo esc_url(plugins_url("../images/reaction/{$image}", __FILE__)); ?>" 
                         width="60" height="60" alt="">
                    <div class="image-actions">
                        <span class="image-filename"><?php echo esc_html($image); ?></span>
                        <a href="#" data-filename="<?php echo esc_attr($image); ?>" class="delete-link ajax-delete">Hapus</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<script>
window.reaction_admin = {
    ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>',
    url: '<?php echo plugins_url('',__FILE__); ?>',
    nonce: '<?php echo wp_create_nonce('reaction_admin_nonce'); ?>'
};
</script>
