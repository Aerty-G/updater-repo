<?php 
/*
Template Name: Reaction Page
*/
defined("ABSPATH") || die("!"); ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
  <?php echo do_shortcode('[sextras_reaction]'); ?>
</body>