jQuery(document).ready(function($) {
    $('.nav-tab-wrapper a').on('click', function(e) {
        e.preventDefault();
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        $('.tab-content').removeClass('active');
        $($(this).attr('href')).addClass('active');
    });
    
    function generate_react_table(reactions) {
      const $react_tbody = $('#reaction-table tbody');
      $react_tbody.empty(); 
      $.each(reactions, function(key, reaction) {
          const imageUrl = reaction_admin.url + '/..' + reaction.image_url;
          const isActive = reaction.active === undefined || reaction.active === true;

          const $row = $('<tr></tr>');

          const $colKey = $('<td></td>').text(key);

          const $colImage = $('<td></td>').append(
              $('<img>', {
                  src: imageUrl,
                  width: 40,
                  height: 40,
                  alt: reaction.text
              }),
              $('<input>', {
                  type: 'hidden',
                  name: `react[${key}][image_url]`,
                  value: reaction.image_url
              })
          );

          const $colText = $('<td></td>').append(
              $('<input>', {
                  type: 'text',
                  name: `react[${key}][text]`,
                  value: reaction.text,
                  class: 'regular-text'
              })
          );

          const $colActive = $('<td>', { style: 'text-align: center;' }).append(
              $('<input>', {
                  type: 'checkbox',
                  name: `react[${key}][active]`,
                  value: '1',
                  checked: isActive
              })
          );

          const $colDelete = $('<td>', { style: 'text-align: center;' }).append(
              $('<a>', {
                  href: '#',
                  text: 'Hapus',
                  class: 'delete-link delete-reaction',
                  'data-react': key
              })
          );

          $row.append($colKey, $colImage, $colText, $colActive, $colDelete);
          $react_tbody.append($row);
      });
    }

    $('#upload-image-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const button = form.find('#upload-image-button');
        const loader = button.siblings('.ajax-loader');
        const response = form.siblings('.ajax-response');
        
        button.prop('disabled', true);
        loader.show();
        response.hide().removeClass('ajax-success ajax-error');
        
        const formData = new FormData(this);
        formData.append('action', 'arch_upload_reaction_image');
        formData.append('security', reaction_admin.nonce);
        
        $.ajax({
            url: reaction_admin.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json'
        })
        .done(function(res) {
            if (res.success) {
                const imageItem = `
                <div class="image-item">
                    <img src="${res.data.url}" width="60" height="60" alt="">
                    <div class="image-actions">
                        <span class="image-filename">${res.data.filename}</span>
                        <a href="#" data-filename="${res.data.filename}" class="delete-link ajax-delete">Hapus</a>
                    </div>
                </div>`;
                
                $('.image-grid').prepend(imageItem);
                form.trigger('reset');
                $('select[name="new_reaction[image_url]"]').append(
                    `<option value="${res.data.filename}">${res.data.filename}</option>`
                );
                
                response.addClass('ajax-success').html(`<p>${res.data.message}</p>`).show();
            } else {
                response.addClass('ajax-error').html(`<p>${res.data}</p>`).show();
            }
        })
        .fail(function() {
            response.addClass('ajax-error').html('<p>Terjadi kesalahan saat mengupload gambar.</p>').show();
        })
        .always(function() {
            button.prop('disabled', false);
            loader.hide();
        });
    });

    $(document).on('click', '.ajax-delete', function(e) {
        e.preventDefault();
        if(!confirm('Serius Ingin Menghapus Gambar ini?')) return;
        const button = $(this);
        const imageItem = button.closest('.image-item');
        const filename = button.data('filename');
        const loader = $('<span class="ajax-loader"></span>');
        
        button.after(loader);
        button.hide();
        
        $.ajax({
            url: reaction_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'arch_delete_reaction_image',
                security: reaction_admin.nonce,
                filename: filename
            },
            dataType: 'json'
        })
        .done(function(res) {
            if (res.success) {
                imageItem.fadeOut(300, function() {
                    $(this).remove();
                });
                
                // Remove from select dropdown
                $(`select[name="new_reaction[image_url]"] option[value="${filename}"]`).remove();
            } else {
                button.show();
                alert(res.data);
            }
        })
        .fail(function() {
            button.show();
            alert('Terjadi kesalahan saat menghapus gambar.');
        })
        .always(function() {
            loader.remove();
        });
    });
    
    $(document).on('click', '.delete-reaction', function(e) {
        e.preventDefault();
        if(!confirm('Serius Ingin Menghapus Reaction ini?')) return;
        const button = $(this);
        const key = button.data('react');
        const react_table = button.closest('.react-items-' + key);
        const loader = $('<span class="ajax-loader"></span>');
        
        button.after(loader);
        button.hide();
        
        $.ajax({
            url: reaction_admin.ajax_url,
            type: 'POST',
            data: {
                action: 'arch_delete_reaction',
                security: reaction_admin.nonce,
                key: key
            },
            dataType: 'json'
        })
        .done(function(res) {
            if (res.success) {
                react_table.fadeOut(300, function() {
                    $(this).remove();
                });
            } else {
                button.show();
                alert(res.data);
            }
        })
        .fail(function() {
            button.show();
            alert('Terjadi kesalahan saat menghapus reaction.');
        })
        .always(function() {
            loader.remove();
        });
    });

    $('#save-reactions-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const button = form.find('#save-reactions-button');
        const loader = button.siblings('.ajax-loader');
        const response = form.siblings('.ajax-response');
        
        button.prop('disabled', true);
        loader.show();
        response.hide().removeClass('ajax-success ajax-error');
        
        const formData = $(this).serializeArray();
        formData.push({
            name: 'action',
            value: 'arch_save_reaction_settings'
        }, {
            name: 'security',
            value: reaction_admin.nonce
        });
        
        $.post(reaction_admin.ajax_url, formData, 'json')
        .done(function(res) {
            if (res.success) {
                response.addClass('ajax-success').html(`<p>${res.data.message}</p>`).show();
                generate_react_table(res.data.reaction);
            } else {
                response.addClass('ajax-error').html(`<p>${res.data}</p>`).show();
            }
        })
        .fail(function() {
            response.addClass('ajax-error').html('<p>Terjadi kesalahan saat menyimpan pengaturan.</p>').show();
        })
        .always(function() {
            button.prop('disabled', false);
            loader.hide();
        });
    });
    
    $('#add-reactions-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const button = form.find('#add-reactions-button');
        const loader = button.siblings('.ajax-loader');
        const response = form.siblings('.ajax-response');
        
        button.prop('disabled', true);
        loader.show();
        response.hide().removeClass('ajax-success ajax-error');
        
        const formData = $(this).serializeArray();
        formData.push({
            name: 'action',
            value: 'arch_add_reaction'
        }, {
            name: 'security',
            value: reaction_admin.nonce
        });
        
        $.post(reaction_admin.ajax_url, formData, 'json')
        .done(function(res) {
            if (res.success) {
                response.addClass('ajax-success').html(`<p>${res.data.message}</p>`).show();
                generate_react_table(res.data.reaction);
                $('input[name="new_reaction[key]"], input[name="new_reaction[text]"]').val('');
                $('select[name="new_reaction[image_url]"]').val($('option:first', this).val());
            } else {
                response.addClass('ajax-error').html(`<p>${res.data}</p>`).show();
            }
        })
        .fail(function() {
            response.addClass('ajax-error').html('<p>Terjadi kesalahan saat menyimpan pengaturan.</p>').show();
        })
        .always(function() {
            button.prop('disabled', false);
            loader.hide();
        });
    });
    
    $('#save-phrase-form').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const button = form.find('#save-phrases-button');
        const loader = button.siblings('.ajax-loader');
        const response = form.siblings('.ajax-response');
        
        button.prop('disabled', true);
        loader.show();
        response.hide().removeClass('ajax-success ajax-error');
        
        const formData = form.serializeArray();
        formData.push({
            name: 'action',
            value: 'arch_save_reaction_phrases'
        }, {
            name: 'security',
            value: reaction_admin.nonce
        });
        
        
        $.post(reaction_admin.ajax_url, formData, 'json')
        .done(function(res) {
            if (res.success) {
                response.addClass('ajax-success').html(`<p>${res.data}</p>`).show();
            } else {
                response.addClass('ajax-error').html(`<p>${res.data}</p>`).show();
            }
        })
        .fail(function() {
            response.addClass('ajax-error').html('<p>Terjadi kesalahan saat menyimpan frasa.</p>').show();
        })
        .always(function() {
            button.prop('disabled', false);
            loader.hide();
        });
    });
    
});