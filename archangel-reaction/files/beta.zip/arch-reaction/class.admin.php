<?php
class Rafael_Admins {
    private $base_url;
    private $config_path;
    private $image_dir;
    private $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    public function __construct($base_url) {
        $this->base_url = $base_url;
        $this->config_path = __DIR__ . '/reaction-config.php';
        $this->image_dir = __DIR__ . '/images/reaction/';
        
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_arch_upload_reaction_image', [$this, 'ajax_upload_image']);
        add_action('wp_ajax_arch_delete_reaction_image', [$this, 'ajax_delete_image']);
        add_action('wp_ajax_arch_save_reaction_settings', [$this, 'ajax_save_settings']);
        add_action('wp_ajax_arch_save_reaction_phrases', [$this, 'ajax_save_phrases']);
        add_action('wp_ajax_arch_add_reaction', [$this, 'ajax_add_reaction']);
        add_action('wp_ajax_arch_delete_reaction', [$this, 'ajax_delete_reaction']);
    }

    public function add_admin_menu() {
        add_menu_page(
            'Pengaturan Reaction',
            'Archangel',
            'manage_options',
            'archangel-reaction-settings',
            [$this, 'render_admin_page'],
            'dashicons-smiley',
            100
        );
    }

    public function enqueue_admin_scripts() {
        wp_enqueue_media();
        wp_enqueue_style('reaction-admin-css', plugin_dir_url(__FILE__) . 'css/admin.css?ver=' . rand());
        wp_enqueue_script('reaction-admin-js', plugin_dir_url(__FILE__) . 'js/admin.js', ['jquery'], filemtime(__DIR__. '/js/admin.js'), true);
    }

    public function render_admin_page() {
        $config = $this->get_config();
        $reactions = $config['react'] ?? [];
        $phrases = $config['phrases'] ?? [];
        $images = $this->get_available_images();

//         if (isset($_POST['save_reactions'])) {
//             $this->save_reactions();
//             echo '<div class="notice notice-success"><p>Pengaturan disimpan!</p></div>';
//             $reactions = $this->get_config()['react'];
//         }
// 
//         if (isset($_POST['upload_image'])) {
//             $this->handle_image_upload();
//             $images = $this->get_available_images();
//         }
// 
//         if (isset($_GET['delete_image'])) {
//             $this->delete_image(sanitize_text_field($_GET['delete_image']));
//             $images = $this->get_available_images();
//         }

        include __DIR__ . '/templates/admin-page.php';
    }

    private function get_config() {
        $example_file = __DIR__ . '/reaction-config.php.example';
        if ( ! file_exists($this->config_path) ) {
            if ( file_exists($example_file) ) {
                if ( copy($example_file, $this->config_path) ) {
                    error_log('File config.php berhasil dibuat dari reaction-config.php.example');
                } else {
                    error_log('Gagal membuat file reaction-config.php dari reaction-config.php.example');
                }
            } else {
                error_log('File config.php.example tidak ditemukan!');
            }
        }
        $config = include $this->config_path;
        if (!isset($config['phrases'])) {
          $config['phrases'] = [
            'prompt' => 'Gimana Reaksi Kalian?',
            'total_responses' => '{count} Respon',
            'show_more' => 'Tampilkan Lebih Banyak',
            'show_less' => 'Sembunyikan',
            'hooks_1' => '#comments',
            'hooks_2' => '.releases'
          ];
          $this->save_config($config);
        }
        return $config;
    }

    private function save_config($config) {
        $content = "<?php\nreturn " . var_export($config, true) . ";\n";
        file_put_contents($this->config_path, $content);
    }

    private function get_available_images() {
        $images = [];
        if (is_dir($this->image_dir)) {
            $files = scandir($this->image_dir);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $ext = pathinfo($file, PATHINFO_EXTENSION);
                if (in_array(strtolower($ext), $this->allowed_types)) {
                    $images[] = $file;
                }
            }
        }
        return $images;
    }

    private function handle_image_upload() {
        if (!empty($_FILES['reaction_image']['name'])) {
            $file = $_FILES['reaction_image'];
            
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $this->allowed_types)) {
                echo '<div class="notice notice-error"><p>Format file tidak didukung!</p></div>';
                return;
            }
            
            $filename = sanitize_file_name($file['name']);
            $target = $this->image_dir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $target)) {
                echo '<div class="notice notice-success"><p>Gambar berhasil diupload!</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>Gagal mengupload gambar.</p></div>';
            }
        }
    }

    private function delete_image($filename) {
        $target = $this->image_dir . sanitize_file_name($filename);
        if (file_exists($target)) {
            unlink($target);
            echo '<div class="notice notice-success"><p>Gambar dihapus!</p></div>';
        }
    }

    private function save_reactions() {
        $config = $this->get_config();
        $new_reactions = [];
        
        foreach ($_POST['react'] as $key => $data) {
            $new_reactions[$key] = [
                'text' => $data['text'],
                'image_alt' => strtolower($data['text']),
                'image_url' => $data['image_url'],
                'active' => isset($data['active'])
            ];
        }
        
        $config['react'] = $new_reactions;
        $this->save_config($config);
    }
    public function ajax_upload_image() {
        check_ajax_referer('reaction_admin_nonce', 'security');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Akses ditolak.', 403);
        }
        
        if (empty($_FILES['reaction_image']['name'])) {
            wp_send_json_error('Tidak ada file yang diupload.');
        }
        
        $file = $_FILES['reaction_image'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($ext, $this->allowed_types)) {
            wp_send_json_error('Format file tidak didukung.');
        }
        
        $filename = sanitize_file_name($file['name']);
        $target = $this->image_dir . $filename;
        
        $counter = 1;
        $fileinfo = pathinfo($filename);
        while (file_exists($target)) {
            $filename = $fileinfo['filename'] . '-' . $counter . '.' . $fileinfo['extension'];
            $target = $this->image_dir . $filename;
            $counter++;
        }
        
        if (move_uploaded_file($file['tmp_name'], $target)) {
            $image_url = plugins_url("images/reaction/{$filename}", __FILE__);
            wp_send_json_success([
                'message' => 'Gambar berhasil diupload!',
                'filename' => $filename,
                'url' => $image_url
            ]);
        } else {
            wp_send_json_error('Gagal mengupload gambar.');
        }
    }
    public function ajax_delete_image() {
        check_ajax_referer('reaction_admin_nonce', 'security');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Akses ditolak.', 403);
        }
        
        if (empty($_POST['filename'])) {
            wp_send_json_error('Nama file tidak valid.');
        }
        
        $filename = sanitize_file_name($_POST['filename']);
        $target = $this->image_dir . $filename;
        
        if (file_exists($target)) {
            if (unlink($target)) {
                wp_send_json_success('Gambar berhasil dihapus.');
            } else {
                wp_send_json_error('Gagal menghapus gambar.');
            }
        } else {
            wp_send_json_error('File tidak ditemukan.');
        }
    }
    
    public function ajax_save_phrases() {
        check_ajax_referer('reaction_admin_nonce', 'security');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Akses ditolak.', 403);
        }
        
        $config = $this->get_config();
        
        $config['phrases'] = [
            'prompt' => $_POST['prompt'],
            'total_responses' => $_POST['total_responses'],
            'show_more' => $_POST['show_more'],
            'show_less' => $_POST['show_less'],
            'hooks_1' => $_POST['hooks_1'],
            'hooks_2' => $_POST['hooks_2']
        ];
        
        $this->save_config($config);
        wp_send_json_success('Frasa berhasil disimpan!');
    }
    
    public function ajax_add_reaction() {
        check_ajax_referer('reaction_admin_nonce', 'security');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Akses ditolak.', 403);
        }
        
        $config = $this->get_config();
        if (empty($_POST['new_reaction'])) wp_send_json_error('Data Kosong.', 404);
        $config['react'][(is_numeric($_POST['new_reaction']['key']) ? $_POST['new_reaction']['key'] : (count($config['react']) - 1) )] = [
            'text' => $_POST['new_reaction']['text'],
            'image_alt' => strtolower($_POST['new_reaction']['text']),
            'image_url' => '/images/reaction/'.$_POST['new_reaction']['image_url'],
            'active' => true
        ];
        $this->save_config($config);
        wp_send_json_success(
          ['message'=>'Reaction Berhasil Ditambahkan!',
            'reaction' => $config['react']
          ]
        );
    }
    
    public function ajax_delete_reaction() {
        check_ajax_referer('reaction_admin_nonce', 'security');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Akses ditolak.', 403);
        }
        
        if (empty($_POST['key']) || !is_numeric($_POST['key'])) {
            wp_send_json_error('Data Key Tidak Valid.');
        }
        
        $key = ($_POST['key']);
        $config = $this->get_config();
        unset($config['react'][$key]);
        $this->save_config($config);
        wp_send_json_success('Reaction Berhasil Dihapus.');
    }
    
    public function ajax_save_settings() {
        check_ajax_referer('reaction_admin_nonce', 'security');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Akses ditolak.', 403);
        }
        
        $config = $this->get_config();
        $new_reactions = [];
        
        if (!empty($_POST['react'])) {
            foreach ($_POST['react'] as $key => $data) {
                $new_reactions[$key] = [
                    'text' => $data['text'],
                    'image_alt' => $data['text'],
                    'image_url' => $data['image_url'],
                    'active' => isset($data['active'])
                ];
            }
        }
        
        
        $config['react'] = $new_reactions;
        $this->save_config($config);
        
        wp_send_json_success(
          ['message'=>'Pengaturan reaction berhasil disimpan!',
          'reaction' => $new_reactions
          ]
        );
    }
}


